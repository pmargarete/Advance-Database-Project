<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dapp";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  
    $driver_id = $_SESSION['driver_id'];
    $pickup_location = $_POST['pickup_location'];
    $dropoff_location = $_POST['dropoff_location'];
    $datetime = $_POST['datetime'];
    $payment_method = $_POST['payment_method'];
    $fare = $_POST['fare'];
    
    $sql = "INSERT INTO `trips` (DriverID, PickUpLoc, DropOffLoc, DateTime, PaymentMethod, Fare)
            VALUES ('$driver_id', '$pickup_location', '$dropoff_location', '$datetime', '$payment_method', '$fare')";
    
    
    if ($conn->query($sql) === TRUE) {
        header("Location: dashboard.php");
        exit();
      }
  }
  
  $conn->close();
?>