<?php
session_start(); 


if (!isset($_SESSION['driver_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<nav class="bottom-nav">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="trip_history.php">Trip History</a></li>
        <li><a href="payout.php">Payout</a></li>
    </ul>
</nav>
