<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriverApp</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap"
      rel="stylesheet"
    />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('nunsbg.jpeg');
            margin: 0;
            padding: 0;
        }

        header {
            background-color: hsl(0, 0%, 0%);
            color: #fff;
            text-align: center;
            padding: 1em;
            font-size: medium;
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin: 0 auto;
            padding: 20% 0;
            text-align: center;
        }

        .section {
            display: none;
            padding: 20px;
            background-color: #fff;
            border: 1px solid gray;
            border-radius: 3px;
            box-shadow: 0px 2px 2px 0px gray;
        }

        .section.active {
            display: block;
        }

        .button-group {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
        }

        .button-group button {
            padding: 10px;
            width: 48%;
            max-width: 100px;
            background-color: hsl(0, 0%, 0%);
            border: 0px;
            color: white;
            cursor: pointer;
        }

        @media (max-width: 600px) {
            .container {
                padding: 40% 0;
            }

            .section {
                padding: 10px;
            }

            .button-group {
                flex-direction: column;
                gap: 10px;
            }

            .button-group button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>DriverApp</h1>
    </header>
    <div class="container">
    

        <section id="login" class="section active">
        <h2>Welcome Back!</h2>
            <form action="login_process.php" method="post">
                <label for="login_email">Email:</label><br>
                <input type="email" id="login_email" name="email" required><br><br>
                
                <label for="login_password">Password:</label><br>
                <input type="password" id="login_password" name="password" required><br><br>
                
                <div class="button-group">
                    <button type="submit" value="Login">Log in</button>
                    <button onclick="window.location.href='signup.php'">Sign Up</button>
                    </div>
            </form>
        </section>

    
</body>
</html>
