<?php
session_start();

if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dapp"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$driver_id = $_SESSION['driver_id'];

$sql = "SELECT DFullName FROM drivers WHERE DriverID = ?";
$stmt = $conn->prepare($sql);

$stmt->bind_param("s", $driver_id);

$stmt->execute();

$stmt->bind_result($fullname);

$stmt->fetch();

$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Driver Profile</title>
  
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #fff;
      color: #fff;
      margin: 0;
      padding: 0;
    }

    .container {
      width: 80%;
      max-width: 600px;
      margin: 0 auto;
      padding: 10% 0; 
      text-align: center;
    }

    h1, p {
      color: #000;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    table, th, td {
      border: 1px solid #fff;
      padding: 8px;
      text-align: center;
    }

    th {
      background-color: #333;
      color: #fff;
    }

    td {
      background-color: #555;
      color: #fff;
    }

    a {
      color: #000;
      text-decoration: none;
      font-size: 16px;
      padding: 10px;
      transition: all 0.3s ease;
    }

    a:hover {
      color: #D8D8D8;
    }

    .bottom-nav {
      width: 100%;
      background-color: #000;
      overflow: auto;
      position: fixed;
      bottom: 0;
      left: 0;
    }

    .bottom-nav ul {
      list-style-type: none;
      margin: 0;
      padding: 0;
      text-align: center;
    }

    .bottom-nav ul li {
      display: inline-block;
      margin-right: 20px;
    }

    .bottom-nav ul li a {
      color: #000;
      text-decoration: none;
      font-size: 16px;
      padding: 10px;
      transition: all 0.3s ease;
    }

    .bottom-nav ul li a:hover {
      color: #D8D8D8;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Driver Profile</h1>
    
    <table>
      <tr>
        <th>Driver ID</th>
        <td><?php echo htmlspecialchars($driver_id); ?></td>
      </tr>
      <tr>
        <th>Full Name</th>
        <td><?php echo htmlspecialchars($fullname); ?></td>
      </tr>
    </table>
    
    <a href="edit_profile.php">Edit Profile</a>
    <br><br>
    <a href="dashboard.php">Back to Dashboard</a>
    

  </div>
</body>
</html>
