<?php
session_start();

if (!isset($_SESSION['driver_id'])) {
    header("Location: dashboard.php"); 
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dapp";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql_trip_history = "SELECT * FROM trips WHERE DriverID = '{$_SESSION['driver_id']}' ORDER BY BookingID DESC";

$result_trip_history = $conn->query($sql_trip_history);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trip History</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        h1, th, td {
            color: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #fff;
            padding: 10px;
        }

        table th {
            background-color: #555;
        }

        table tr:nth-child(even) {
            background-color: #444;
        }

        table tr:hover {
            background-color: #666;
        }

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background-color: #333;
            padding: 10px 0;
            color: #fff;
            text-align: center;
        }
        
        .bottom-nav {
            width: 100%;
            background-color: #333;
            position: fixed;
            bottom: 0;
            left: 0;
            padding: 10px 0;
            text-align: center;
        }

        .bottom-nav ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .bottom-nav ul li {
            display: inline-block;
            margin-right: 20px;
        }

        .bottom-nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            padding: 10px;
            transition: all 0.3s ease;
        }

        .bottom-nav ul li a:hover {
            color: #ccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include 'navbar.php'; ?>

        <h1>Trip History</h1>

        <table>
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Driver ID</th>
                    <th>Pickup Location</th>
                    <th>Dropoff Location</th>
                    <th>Date & Time</th>
                    <th>Payment Method</th>
                    <th>Fare</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result_trip_history->num_rows > 0): ?>
                    <?php while ($row = $result_trip_history->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['BookingID']); ?></td>
                            <td><?php echo htmlspecialchars($row['DriverID']); ?></td>
                            <td><?php echo htmlspecialchars($row['PickUpLoc']); ?></td>
                            <td><?php echo htmlspecialchars($row['DropOffLoc']); ?></td>
                            <td><?php echo htmlspecialchars($row['DateTime']); ?></td>
                            <td><?php echo htmlspecialchars($row['PaymentMethod']); ?></td>
                            <td>$<?php echo number_format($row['Fare'], 2); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8">No trips found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <footer class="bottom-nav">
        <?php include 'navbar.php'; ?>
    </footer>
</body>
</html>
