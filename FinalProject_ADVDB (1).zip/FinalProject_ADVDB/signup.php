<?php
session_start();


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dapp";


$email = $password = $fullname = $contact_number = $license_number = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $license_number = mysqli_real_escape_string($conn, $_POST['license_number']);

    $sql = "INSERT INTO drivers (DEmail, DPassword, DFullName, DContactNum, DLicenseNo)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);


    if ($stmt === false) {
        die('MySQL prepare error: ' . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("sssss", $email, $password, $fullname, $contact_number, $license_number);

    if (!empty($email) && !empty($password) && !empty($fullname) && !empty($contact_number) && !empty($license_number)) {
        if ($stmt->execute()) {

          header("Location: dashboard.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        echo "All fields are required.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Driver Sign-Up</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #000;
      color: #333;
      margin: 0;
      padding: 0;
    }

    .container {
      width: 80%;
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    form {
      text-align: center;
    }

    label {
      display: block;
      margin-bottom: 8px;
    }

    input[type=email], input[type=password], input[type=text], input[type=tel] {
      width: calc(80% - 20px);
      padding: 10px;
      margin-bottom: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      font-size: 16px;
      box-sizing: border-box;
    }

    input[type=submit] {
      background-color: #000;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    input[type=submit]:hover {
      background-color: #D8D8D8;
    }

    a {
      display: inline-block;
      margin-top: 15px;
      color: #333;
      text-decoration: none;
    }

    a:hover {
      color: #D8D8D8;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Register Account</h1>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <label for="email">Email:</label><br>
      <input type="email" id="email" name="email" required><br><br>
      
      <label for="password">Password:</label><br>
      <input type="password" id="password" name="password" required><br><br>
      
      <label for="fullname">Full Name:</label><br>
      <input type="text" id="fullname" name="fullname" required><br><br>
      
      <label for="contact_number">Contact Number:</label><br>
      <input type="tel" id="contact_number" name="contact_number" required><br><br>
      
      <label for="license_number">License Number:</label><br>
      <input type="text" id="license_number" name="license_number" required><br><br>
      
      <input type="submit" value="Sign Up">
     
      <a href="index.php">Already have an account? Login </a>
      </form>

  </div>
</body>
</html>
