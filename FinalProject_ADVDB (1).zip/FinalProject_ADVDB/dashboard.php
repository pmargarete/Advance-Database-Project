<?php
session_start();
include_once 'db_connection.php';
include_once 'functions.php';

if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit();
}

$total_earnings = getTotalEarnings($_SESSION['driver_id'], $conn);


$deduction = $total_earnings * 0.20;
$net_earnings = $total_earnings - $deduction;

$total_trips = getNumberOfTrips($_SESSION['driver_id'], $conn);


$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DriverApp</title>
    <link rel="stylesheet" type="text/css" href="navbar.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin: 0 auto;
            padding: 10% 0;
            text-align: center;
        }

        h2 {
            color: #fff;
        }

        .data-container {
            background-color: #333;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.5);
        }

        .data-container h3 {
            color: #fff;
        }

        .data-container p {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            margin-top: 10px;
        }

        button {
            padding: 10px 20px;
            background-color: #ooo;
            color: #000;
            border: none;
            cursor: pointer;
            font-size: 16px;
            margin: 20px;
            border-radius: 5px;
                }

        .bottom-nav {
            width: 100%;
            background-color: #333;
            position: fixed;
            bottom: 0;
            left: 0;
            margin: 7px
            padding: 10px 0;
        }

        .bottom-nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
        }

        .bottom-nav ul li {
            display: inline-block;
            margin-right: 20px;
        }

        .bottom-nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            padding: 10px;
            transition: all 0.3s ease;
        }

        .bottom-nav ul li a:hover {
            color: #ccc;
        }
    </style>
</head>
<body>
    <div class="container">
       
        <h2>Welcome, <?php echo $_SESSION['DFullName']; ?></h2>
        <p>Driver ID: <?php echo $_SESSION['driver_id']; ?></p>

        <div class="data-container">
            <h3>Number of Trips</h3>
            <p><?php echo $total_trips; ?></p>
        </div>

        <div class="data-container">
            <h3>Total Earnings</h3>
            <p>$<?php echo number_format($total_earnings, 2); ?></p>
        </div>

        <a href="add_trip.php"><button>Add Trip</button></a>
        <a href="profile.php"><button>Profile</button></a>
         <a href="logout.php"><button>Logout</button></a>
    </div>

    <div class="bottom-nav">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="trip_history.php">Trip History</a></li>
            <li><a href="payout.php">Payout</a></li>
        
        </ul>
    </div>
</body>
</html>
