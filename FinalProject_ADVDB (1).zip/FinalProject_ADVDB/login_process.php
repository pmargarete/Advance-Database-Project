<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dapp";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM drivers WHERE DEmail='$email' AND DPassword='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc();
  $_SESSION['driver_id'] = $row['DriverID'];
  $_SESSION['fullname'] = $row['FullName'];
  
  header("Location: dashboard.php"); 
} else {
  echo "Login failed. Invalid credentials.";
}

$conn->close();
?>
