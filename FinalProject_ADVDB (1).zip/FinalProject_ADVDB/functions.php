<?php

function getTotalEarnings($driver_id, $conn) {
    $total_earnings = 0;
    $sql = "SELECT SUM(Fare) AS total_earnings FROM trips WHERE DriverID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $driver_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $total_earnings = $row['total_earnings'];
    }
    
    $stmt->close();
    
    return $total_earnings;
}

function getNumberofTrips($driver_id, $conn) {
    $total_earnings = 0;
    $sql = "SELECT COUNT(BookingID) AS total_trips FROM trips WHERE DriverID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $driver_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $total_earnings = $row['total_trips'];
    }
    
    $stmt->close();
    
    return $total_earnings;
}

function addTrip($driver_id, $fare, $conn) {
    $sql = "INSERT INTO trips (DriverID, Fare) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("id", $driver_id, $fare);
    $stmt->execute();
    $stmt->close();
}

function recordPayout($driver_id, $total_earnings, $deduction, $net_earnings, $conn) {
    $sql_insert_payout = "INSERT INTO payouts (DriverID, GrossEarnings, Deduction, NetEarnings, PayoutDate)
                          VALUES (?, ?, ?, ?, NOW())";
    $stmt_insert_payout = $conn->prepare($sql_insert_payout);
    $stmt_insert_payout->bind_param("iddd", $driver_id, $total_earnings, $deduction, $net_earnings);
    $stmt_insert_payout->execute();
    $stmt_insert_payout->close();
    
    $sql_update_earnings = "UPDATE trips SET Fare = 0 WHERE DriverID = ?";
    $stmt_update_earnings = $conn->prepare($sql_update_earnings);
    $stmt_update_earnings->bind_param("i", $driver_id);
    $stmt_update_earnings->execute();
    $stmt_update_earnings->close();
}
?>
