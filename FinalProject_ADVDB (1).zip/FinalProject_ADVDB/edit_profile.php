<?php
session_start();

if (!isset($_SESSION['driver_id'])) {
  header("Location: login.php");
  exit();
}

$fullname = $_SESSION['fullname'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $new_fullname = $_POST['new_fullname'];
  
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "dapp";

  
  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $driver_id = $_SESSION['driver_id'];
  
  $sql = "UPDATE drivers SET DFullname = ? WHERE DriverID = ?";

  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ss", $new_fullname, $driver_id);

  if ($stmt->execute()) {
    $_SESSION['fullname'] = $new_fullname; 
    header("Location: profile.php"); 
    exit();
  } else {
    echo "Error updating record: " . $conn->error;
  }

  $stmt->close();
  $conn->close();

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Profile</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      color: #333;
      margin: 0;
      padding: 0;
    }

    .container {
      width: 80%;
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    form {
      text-align: center;
    }

    label {
      display: block;
      margin-bottom: 8px;
    }

    input[type=text] {
      width: calc(100% - 20px);
      padding: 10px;
      margin-bottom: 20px;
      border: 1px solid #ccc;
      border-radius: 4px;
      font-size: 16px;
      box-sizing: border-box;
    }

    input[type=submit] {
      background-color: #000;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    input[type=submit]:hover {
      background-color: #D8D8D8;
    }

    a {
      display: inline-block;
      margin-top: 10px;
      color: #333;
      text-decoration: none;
    }

    a:hover {
      color: #D8D8D8;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Edit Profile</h1>
    
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <label for="new_fullname">New Full Name:</label><br>
      <input type="text" id="new_fullname" name="new_fullname" value="<?php echo htmlspecialchars($fullname); ?>" required><br><br>
      
      <input type="submit" value="Update">
    </form>
    
    <a href="profile.php">Cancel</a>
  </div>
</body>
</html>
