<?php
session_start();

if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['payout_claimed']) || $_SESSION['payout_claimed'] !== true) {
    header("Location: payout.php");
    exit();
}

unset($_SESSION['payout_claimed']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Payout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin: 0 auto;
            padding: 10% 0;
        }

        h1, p {
            color: #fff;
        }

        .message {
            background-color: #333;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.5);
        }

        .message p {
            font-size: 24px;
            font-weight: bold;
            margin-top: 10px;
        }

        .bottom-nav {
            width: 100%;
            background-color: #fff;
            overflow: auto;
            position: fixed;
            bottom: 0;
            left: 0;
        }

        .bottom-nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        .bottom-nav ul li {
            display: inline-block;
            margin-right: 20px;
        }

        .bottom-nav ul li a {
            color: #000;
            text-decoration: none;
            font-size: 16px;
            padding: 10px;
            transition: all 0.3s ease;
        }

        .bottom-nav ul li a:hover {
            color: #D8D8D8;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Claim Successful!</h1>

        <div class="message">
            <p>Your payout has been successfully claimed.</p>
        </div>

        <div class="bottom-nav">
            <ul>
                <li><a href="dashboard.php">Back to Dashboard</a></li>
            </ul>
        </div>
    </div>
</body>
</html>
