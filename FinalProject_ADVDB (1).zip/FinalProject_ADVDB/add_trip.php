<?php
session_start();

if (!isset($_SESSION['driver_id'])) {
  header("Location: login.php");
  exit();
}

include_once "add_trip_process.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Trip</title>
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #000;
      color: #fff;
      margin: 0;
      padding: 0;
    }

    .container {
      width: 80%;
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
      text-align: center;
      background-color: #333; 
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.5); 
    }

    h1 {
      color: #fff;
    }

    form {
      text-align: left;
      margin-top: 20px;
    }

    label {
      display: block;
      margin-bottom: 10px;
      color: #fff;
    }

    input[type="text"],
    input[type="datetime-local"],
    select {
      width: calc(100% - 22px);
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      background-color: #fff;
      color: #333;
      font-size: 16px;
    }

    input[type="submit"] {
      padding: 10px 20px;
      background-color: #ooo;
      color: #000;
      border: none;
      cursor: pointer;
      font-size: 16px;
      border-radius: 5px;
    }

    input[type="submit"]:hover {
      background-color: #ddd;
    }

    button {
      padding: 10px 20px;
      background-color: #ooo;
      color: #000;
      border: none;
      cursor: pointer;
      font-size: 16px;
      border-radius: 5px;

    }

  </style>
</head>
<body>
  <div class="container">
    <h1>Add Trip</h1>
    
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <label for="pickup_location">Pickup Location:</label>
      <input type="text" id="pickup_location" name="pickup_location" required><br><br>
      
      <label for="dropoff_location">Dropoff Location:</label>
      <input type="text" id="dropoff_location" name="dropoff_location" required><br><br>
      
      <label for="datetime">Date and Time:</label>
      <input type="datetime-local" id="datetime" name="datetime" required><br><br>
      
      <label for="payment_method">Payment Method:</label>
      <select id="payment_method" name="payment_method" required>
        <option value="cash">Cash</option>
        <option value="e-cash">E-Cash</option>
      </select><br><br>
      
      <label for="fare">Fare:</label>
      <input type="text" id="fare" name="fare" required><br><br>
      
      <button onclick="window.location.href='dashboard.php'">Cancel</button>
      <input type="submit" value="Add"> 
      </form>
  </div>
</body>
</html>
