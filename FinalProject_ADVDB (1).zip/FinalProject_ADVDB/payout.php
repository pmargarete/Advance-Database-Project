<?php
session_start();
include_once 'db_connection.php';

if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dapp";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$total_earnings = 0;
$deduction = 0;
$net_earnings = 0;
$incentives = 0;

function getNumberOfTrips($driverID, $conn) {

    $sql = "SELECT COUNT(*) AS num_trips FROM trips WHERE DriverID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $driverID);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['num_trips'];
}

    $sql_total_earnings = "SELECT SUM(Fare) AS total_earnings FROM trips WHERE DriverID = ?";
    $stmt = $conn->prepare($sql_total_earnings);
    $stmt->bind_param("s", $_SESSION['driver_id']);
    $stmt->execute();
    $result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $total_earnings = $row['total_earnings'];

    $deduction = $total_earnings * 0.20;

    $numberOfTrips = getNumberOfTrips($_SESSION['driver_id'], $conn);
    if ($numberOfTrips >= 10) {
        $incentives = 20;
    }

    $net_earnings = $total_earnings - $deduction + $incentives;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['claim'])) {

    
    $sql_update = "INSERT INTO payouts (DriverID, GrossEarnings, Deduction, Incentives, NetEarnings, PayoutDate) VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("sddds", $_SESSION['driver_id'], $total_earnings, $deduction, $incentives, $net_earnings);
    $stmt_update->execute();

    if ($stmt_update->affected_rows > 0) {
        echo "<script>alert('Earnings successfully claimed!');</script>";
    } else {
        echo "<script>alert('Failed to claim earnings. Please try again later.');</script>";
    }

   //back to dashboard
    header("Location: dashboard.php");
    exit();
}

$sql_payouts = "SELECT * FROM payouts WHERE DriverID = ?";
$stmt_payouts = $conn->prepare($sql_payouts);
$stmt_payouts->bind_param("s", $_SESSION['driver_id']);
$stmt_payouts->execute();
$result_payouts = $stmt_payouts->get_result();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payout</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            max-width: 800px; 
            margin: 0 auto;
            padding: 10% 0;
            text-align: center;
        }

        h1 {
            color: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #fff;
            padding: 10px;
        }

        table th {
            background-color: #555;
        }

        table tr:nth-child(even) {
            background-color: #444;
        }

        table tr:hover {
            background-color: #666;
        }

        .bottom-nav {
            width: 100%;
            background-color: #333;
            position: fixed;
            bottom: 0;
            left: 0;
            padding: 10px 0;
            text-align: center;
        }

        .bottom-nav ul {
            list-style-type: none;
            padding: 0;
        }

        .bottom-nav ul li {
            display: inline-block;
            margin-right: 20px;
        }

        .bottom-nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            padding: 10px;
            transition: all 0.3s ease;
        }

        .bottom-nav ul li a:hover {
            color: #ccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Payout</h1>
        
        <table>
            <tr>
                <th>Payout ID</th>
                <th>Driver ID</th>
                <th>Gross Earnings</th>
                <th>Deduction (20%)</th>
                <th>Incentives</th>
                <th>Net Earnings</th>
                <th>Payout Date</th>
            </tr>
            <?php while ($row = $result_payouts->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['PayoutID']); ?></td>
                    <td><?php echo htmlspecialchars($row['DriverID']); ?></td>
                    <td>$<?php echo number_format($row['GrossEarnings'], 2); ?></td>
                    <td>$<?php echo number_format($row['Deduction'], 2); ?></td>
                    <td>$<?php echo number_format($row['Incentives'], 2); ?></td>
                    <td>$<?php echo number_format($row['NetEarnings'], 2); ?></td>
                    <td><?php echo htmlspecialchars($row['PayoutDate']); ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
        
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <input type="submit" name="claim" value="Claim" style="background-color: #fff; color: black; border: none; padding: 10px 20px; cursor: pointer; border-radius: 5px; margin: 30px;">
        </form>
    </div>

    <?php include 'navbar.php'; ?>
</body>
</html>
